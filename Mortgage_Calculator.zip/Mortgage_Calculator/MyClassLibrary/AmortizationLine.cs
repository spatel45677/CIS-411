﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class AmortizationLine
    {
        private decimal _endingBalance = 0;
        private decimal _beginningBalance = 0;
        private decimal _principalPaid = 0;
        private decimal _interestPaid = 0;


        public AmortizationLine(decimal Principal, decimal Interest_Rate, decimal Payment)
        {
            _interestPaid = Principal * Interest_Rate;
            _beginningBalance = Principal;
            _principalPaid = Payment - _interestPaid;
            _endingBalance = Principal - _principalPaid;

        }

        public decimal Ending_Balance
        {
            get { return _endingBalance; }

        }

        public decimal Beginning_Balance
        {
            get { return _beginningBalance; }
        }

        public decimal Interest_Paid
        {
            get { return _interestPaid; }
        }

        public decimal Principal_Paid
        {
            get { return _principalPaid; }
        }

    }
}
