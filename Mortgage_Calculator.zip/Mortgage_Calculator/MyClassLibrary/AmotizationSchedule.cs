﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class AmortizationSchedule
    {
        AmortizationLine[] mySchedule;

        public AmortizationSchedule(decimal Principal, decimal MonthlyPayment, int NumberofMonths, decimal MonthlyInterestRate)
        {
            mySchedule = new AmortizationLine[NumberofMonths + 1];
            mySchedule[0] = new AmortizationLine(Principal, 0, 0);
            for (int intMonth = 1; intMonth <= NumberofMonths; intMonth++)
            {
                mySchedule[intMonth] = new AmortizationLine(mySchedule[intMonth - 1].Ending_Balance, MonthlyInterestRate, MonthlyPayment);
            }

        }

        public AmortizationLine[] Schedule
        {
            get { return mySchedule; }
        }

    }
}
