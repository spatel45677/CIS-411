﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClassLibrary
{
    public class PaymentCalculator
    {

        public AmortizationLine[] Schedule
        {
            get
            {
                return new AmortizationSchedule(Principal, Monthly_Payment, Months, Monthly_Interest_Rate).Schedule;
            }
        }

        private decimal _principal = 100000;
        private decimal _interestRate = 0.06M;
        private int _months = 120;

        public decimal Principal
        {
            get { return _principal; }
            set
            {
                if (value > 0)
                {
                    _principal = value;
                }
            }
        }

        public decimal Interest_Rate
        {
            get { return _interestRate;}
            set
            {
                if (value > 0)
                {
                    _interestRate = value;
                }
            }
        }

        public int Months
        {
            get { return _months; }
            set
            {
                if (value > 0)
                {
                    _months = value;
                }
            }
        }

        public decimal Monthly_Interest_Rate
        {
            get { return _interestRate / 12; }
        }


        public decimal Monthly_Payment
        {
            get {
                decimal monthly_payment;

                monthly_payment = (Monthly_Interest_Rate + (Monthly_Interest_Rate / (decimal)(Math.Pow((double)(1 + Monthly_Interest_Rate), (double)Months) - 1))) * Principal;

                return monthly_payment;

            }
        }
        



    }
}
