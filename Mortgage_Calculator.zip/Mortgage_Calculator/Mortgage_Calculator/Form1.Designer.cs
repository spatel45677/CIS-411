﻿namespace Mortgage_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrincipal = new System.Windows.Forms.Label();
            this.lblInterestRate = new System.Windows.Forms.Label();
            this.lblMonths = new System.Windows.Forms.Label();
            this.txtPrincipal = new System.Windows.Forms.TextBox();
            this.txtInterestRate = new System.Windows.Forms.TextBox();
            this.txtMonths = new System.Windows.Forms.TextBox();
            this.lblMortgageCalc = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblMontlyPayment = new System.Windows.Forms.Label();
            this.lblMonthlyPayment2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPrincipal
            // 
            this.lblPrincipal.AutoSize = true;
            this.lblPrincipal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrincipal.Location = new System.Drawing.Point(76, 186);
            this.lblPrincipal.Name = "lblPrincipal";
            this.lblPrincipal.Size = new System.Drawing.Size(107, 29);
            this.lblPrincipal.TabIndex = 0;
            this.lblPrincipal.Text = "Principal";
            // 
            // lblInterestRate
            // 
            this.lblInterestRate.AutoSize = true;
            this.lblInterestRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInterestRate.Location = new System.Drawing.Point(76, 246);
            this.lblInterestRate.Name = "lblInterestRate";
            this.lblInterestRate.Size = new System.Drawing.Size(148, 29);
            this.lblInterestRate.TabIndex = 1;
            this.lblInterestRate.Text = "Interest Rate";
            // 
            // lblMonths
            // 
            this.lblMonths.AutoSize = true;
            this.lblMonths.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonths.Location = new System.Drawing.Point(76, 312);
            this.lblMonths.Name = "lblMonths";
            this.lblMonths.Size = new System.Drawing.Size(91, 29);
            this.lblMonths.TabIndex = 2;
            this.lblMonths.Text = "Months";
            // 
            // txtPrincipal
            // 
            this.txtPrincipal.Location = new System.Drawing.Point(274, 186);
            this.txtPrincipal.Name = "txtPrincipal";
            this.txtPrincipal.Size = new System.Drawing.Size(108, 26);
            this.txtPrincipal.TabIndex = 3;
            // 
            // txtInterestRate
            // 
            this.txtInterestRate.Location = new System.Drawing.Point(274, 254);
            this.txtInterestRate.Name = "txtInterestRate";
            this.txtInterestRate.Size = new System.Drawing.Size(108, 26);
            this.txtInterestRate.TabIndex = 4;
            // 
            // txtMonths
            // 
            this.txtMonths.Location = new System.Drawing.Point(274, 320);
            this.txtMonths.Name = "txtMonths";
            this.txtMonths.Size = new System.Drawing.Size(108, 26);
            this.txtMonths.TabIndex = 5;
            // 
            // lblMortgageCalc
            // 
            this.lblMortgageCalc.AutoSize = true;
            this.lblMortgageCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMortgageCalc.Location = new System.Drawing.Point(279, 55);
            this.lblMortgageCalc.Name = "lblMortgageCalc";
            this.lblMortgageCalc.Size = new System.Drawing.Size(290, 32);
            this.lblMortgageCalc.TabIndex = 6;
            this.lblMortgageCalc.Text = "Mortgage Calculator";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(158, 395);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(168, 58);
            this.btnSubmit.TabIndex = 7;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblMontlyPayment
            // 
            this.lblMontlyPayment.AutoSize = true;
            this.lblMontlyPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMontlyPayment.Location = new System.Drawing.Point(42, 508);
            this.lblMontlyPayment.Name = "lblMontlyPayment";
            this.lblMontlyPayment.Size = new System.Drawing.Size(234, 32);
            this.lblMontlyPayment.TabIndex = 8;
            this.lblMontlyPayment.Text = "Monthly Payment";
            // 
            // lblMonthlyPayment2
            // 
            this.lblMonthlyPayment2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblMonthlyPayment2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMonthlyPayment2.Location = new System.Drawing.Point(301, 508);
            this.lblMonthlyPayment2.Name = "lblMonthlyPayment2";
            this.lblMonthlyPayment2.Size = new System.Drawing.Size(190, 44);
            this.lblMonthlyPayment2.TabIndex = 9;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(528, 162);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(730, 583);
            this.dataGridView1.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1317, 808);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblMonthlyPayment2);
            this.Controls.Add(this.lblMontlyPayment);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblMortgageCalc);
            this.Controls.Add(this.txtMonths);
            this.Controls.Add(this.txtInterestRate);
            this.Controls.Add(this.txtPrincipal);
            this.Controls.Add(this.lblMonths);
            this.Controls.Add(this.lblInterestRate);
            this.Controls.Add(this.lblPrincipal);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrincipal;
        private System.Windows.Forms.Label lblInterestRate;
        private System.Windows.Forms.Label lblMonths;
        private System.Windows.Forms.TextBox txtPrincipal;
        private System.Windows.Forms.TextBox txtInterestRate;
        private System.Windows.Forms.TextBox txtMonths;
        private System.Windows.Forms.Label lblMortgageCalc;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblMontlyPayment;
        private System.Windows.Forms.Label lblMonthlyPayment2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

