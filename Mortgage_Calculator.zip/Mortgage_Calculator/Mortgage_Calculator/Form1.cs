﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyClassLibrary;

namespace Mortgage_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

            PaymentCalculator calc1 = new PaymentCalculator();

            calc1.Principal = decimal.Parse(txtPrincipal.Text);
            calc1.Interest_Rate = decimal.Parse(txtInterestRate.Text);
            calc1.Months = int.Parse(txtMonths.Text);

            lblMonthlyPayment2.Text = calc1.Monthly_Payment.ToString("C");

            dataGridView1.DataSource = calc1.Schedule;


        }

        
    }
}
